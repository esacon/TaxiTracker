package com.example.gps_trackerapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {

    private EditText ipEditText;
    private EditText portEditText;
    private TextView latitudeText;
    private TextView longitudeText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Grant permissions.
        requestPermissions();

        // Get information for sending the message.
        ipEditText = findViewById(R.id.ipEditText);
        portEditText = findViewById(R.id.portEditText);
        latitudeText = findViewById(R.id.latitudeText);
        longitudeText = findViewById(R.id.longitudeText);
    }

    public void sendTCP(View view) {

        String destIP = ipEditText.getText().toString().trim();
        int port = Integer.valueOf(portEditText.getText().toString().trim());

        // Grant permissions.
        requestPermissions();

        if (checkPermissions()) {
            if (!destIP.equals("") && port != 0) {

                GpsTracker gpsTracker = new GpsTracker(MainActivity.this);
                MessageSenderTCP ms = new MessageSenderTCP(destIP, port);

                if (gpsTracker.canGetLocation()) {
                    double latitude = gpsTracker.getLatitude();
                    double longitude = gpsTracker.getLongitude();
                    // Send Message.
                    String url = String.format("https://www.google.com/maps/search/%f,%f", latitude, longitude);
                    String message = String.format("¡Hola! Mis coordenadas son:\n\nLatitud: %.8f \nLongitud: %.8f \nGoogle Maps: %s", latitude, longitude, url);
                    latitudeText.setText(String.format("Latitud:\t%s", latitude));
                    longitudeText.setText(String.format("Longitud:\t%s", longitude));
                    ms.execute(message);

                    // Success notification.
                    Toast.makeText(getApplicationContext(), "Mensaje enviado con éxito.", Toast.LENGTH_LONG).show();
                } else {
                    gpsTracker.showSettingsAlert();
                }
            } else {
                Toast.makeText(getApplicationContext(), "Ha ocurrido un error, por favor revise los datos.", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(getApplicationContext(), "Por favor acepte todos los permisos.", Toast.LENGTH_LONG).show();
            requestPermissions();
        }
    }

    public void sendUDP(View view) {

        String destIP = ipEditText.getText().toString().trim();
        int port = Integer.valueOf(portEditText.getText().toString().trim());

        // Grant permissions.
        requestPermissions();

        if (checkPermissions()) {
            if (!destIP.equals("") && port != 0) {

                GpsTracker gpsTracker = new GpsTracker(MainActivity.this);
                MessageSenderUDP ms = new MessageSenderUDP(destIP, port);

                if (gpsTracker.canGetLocation()) {
                    double latitude = gpsTracker.getLatitude();
                    double longitude = gpsTracker.getLongitude();
                    // Send Message.
                    String url = String.format("https://www.google.com/maps/search/%f,%f", latitude, longitude);
                    String message = String.format("¡Hola! Mis coordenadas son:\n\nLatitud: %.8f \nLongitud: %.8f \nGoogle Maps: %s", latitude, longitude, url);
                    latitudeText.setText(String.format("Latitud:\t%s", latitude));
                    longitudeText.setText(String.format("Longitud:\t%s", longitude));
                    ms.execute(message);

                    // Success notification.
                    Toast.makeText(getApplicationContext(), "Mensaje enviado con éxito.", Toast.LENGTH_LONG).show();
                } else {
                    gpsTracker.showSettingsAlert();
                }
            } else {
                Toast.makeText(getApplicationContext(), "Ha ocurrido un error, por favor revise los datos.", Toast.LENGTH_LONG).show();
                return;
            }
        } else {
            Toast.makeText(getApplicationContext(), "Por favor acepte todos los permisos.", Toast.LENGTH_LONG).show();
            requestPermissions();
            return;
        }
    }

    private boolean checkPermissions() {
        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        return false;
    }

    private void requestPermissions() {
        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1000);
        }
        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1000);
        }
        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.INTERNET}, 1000);
        }
    }
}